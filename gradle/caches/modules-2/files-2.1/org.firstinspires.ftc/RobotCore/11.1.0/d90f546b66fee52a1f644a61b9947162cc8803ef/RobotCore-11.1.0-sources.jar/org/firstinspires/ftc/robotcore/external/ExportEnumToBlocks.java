/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.firstinspires.ftc.robotcore.external;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.qualcomm.robotcore.hardware.HardwareDevice;
import com.qualcomm.robotcore.hardware.configuration.annotations.DeviceProperties;

/**
 * {@link ExportEnumToBlocks} indicates that an enum is exported to the Blocks programming environment.
 * This annotation provides a way for the Java coder to specify the color of the enum block.
 *
 * The enum must satisfy all of these requirements:
 * <ul>
 * <li> it has the ExportEnumToBlocks annotation
 * <li> it is public
 * </ul>
 *
 * @author lizlooney@google.com (Liz Looney)
 */
@Documented
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface ExportEnumToBlocks {
  /**
   * The hue of the block.
   */
  int color() default 151;
}
